Xie's Mod June 3rd for Minecraft 1.5.x!

Installation:
Extract this zip into .minecraft/mods (this readme file should be in the mods directory along with the "Xie" folder - this readme can of course be deleted)